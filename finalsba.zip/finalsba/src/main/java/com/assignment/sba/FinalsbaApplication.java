package com.assignment.sba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalsbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalsbaApplication.class, args);
	}

}

