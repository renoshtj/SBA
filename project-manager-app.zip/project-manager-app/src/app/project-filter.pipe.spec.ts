import { ProjectFilterPipe } from './project-filter.pipe';

describe('ProjectFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ProjectFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
